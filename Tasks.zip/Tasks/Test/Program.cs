﻿using System;
using Tasks.Model;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            PriorityTasksQueue ptq = new PriorityTasksQueue();
            var t1 = new CalculateTask("Task 1", "3(15+11)");
            ptq.AddTask(t1);
            Console.WriteLine(ptq.ToString());
            var result = t1.Execute();
            Console.WriteLine("Execute Task 1: Output = " + result.Output);


            ptq.AddTask(new CalculateTask("Task 2", "20*5+3)"));
            Console.WriteLine(ptq.ToString());
            ptq.AddTask(new PermuteTask("Task 3", "abc"));
            Console.WriteLine(ptq.ToString());
            ptq.AddTask(new PermuteTask("Task 4", "123"));
            Console.WriteLine(ptq.ToString());
            ptq.AddTask(new CalculateTask("Task 5", "1+1"));
            Console.WriteLine(ptq.ToString());

            ptq.PrioritizeTask("Task 4", 2);
            Console.WriteLine(ptq.ToString());
            ptq.PrioritizeTask("Task 1", 4);
            Console.WriteLine(ptq.ToString());
            ptq.PrioritizeTask("Task 2", 0);
            Console.WriteLine(ptq.ToString());
            ptq.RemoveTask("Task 3");
            Console.WriteLine(ptq.ToString());

            //ptq.Dequeue();
            //Console.WriteLine(ptq.ToString());


            Console.ReadKey();

        }
    }
}
