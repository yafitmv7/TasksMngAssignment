﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tasks.Model
{
    public class TaskExecute
    {
        public Task task { get; set; }
        public TaskExecuteData executeData { get; set; }

        public TaskExecute(Task t)
        {
            task = t;
            executeData = new TaskExecuteData();
        }

        public ExecStatus Execute()
        {
            executeData = task.Execute();
            return executeData.ExecutionStatus;
        }
    }
}
