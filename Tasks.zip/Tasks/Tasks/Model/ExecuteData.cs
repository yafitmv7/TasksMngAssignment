﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tasks.Model
{
    public class ExecuteData
    {
        public IEnumerable<Model.Task> AllTasks { get; set; }
        public int nRemainingTasks { get; set; }
    }
}
