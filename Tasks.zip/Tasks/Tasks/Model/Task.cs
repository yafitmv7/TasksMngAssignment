﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Tasks.Model;

namespace Tasks.Model
{
    public abstract class Task
    {
        public string Name { get; set; }
        public TaskType Type { get; set; }
        //public int Priority { get; set; }
        public string Input { get; set; }
        public TaskExecuteData ExecuteData { get; set; }

        public abstract TaskExecuteData Execute();

        public Task() { }

        public Task(string name, string input)
        {
            Name = name;
            Input = input;
            ExecuteData = new TaskExecuteData()
            {
                ExecutionStatus = ExecStatus.Awaiting,
                FailureReason = "N/A",
                Output = string.Empty
            };
        }

        protected void setFailureStatus(Exception ex)
        {
            ExecuteData.ExecutionStatus = ExecStatus.Failed;
            ExecuteData.FailureReason = ex.Message;
            ExecuteData.Output = "N/A";
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public enum TaskType
    {
        Calculate = 0,
        Premutate = 1
    }



    public class CalculateTask : Task
    {
        public CalculateTask(string name, string input)
            : base(name, input)
        {
            Type = TaskType.Calculate;
        }

        public override TaskExecuteData Execute()
        {
            try
            {
                var input = Regex.Replace(Input, @"(\d+)(\()", "$1*$2");

                DataTable dt = new DataTable();
                var result = dt.Compute(input, "");
                ExecuteData.Output = result.ToString();
                ExecuteData.ExecutionStatus = ExecStatus.Succeeded;
            }
            catch (Exception ex)
            {
                setFailureStatus(ex);
            }
            return ExecuteData;
        }

    }


    public class PermuteTask : Task
    {
        public PermuteTask(string name, string input)
            : base(name, input)
        {
            Type = TaskType.Premutate;
        }

        public override TaskExecuteData Execute()
        {
            try
            {
                char[] arr = Input.ToCharArray();
                string res = string.Empty;
                GetPer(arr, ref res);
                ExecuteData.Output = res;
                ExecuteData.ExecutionStatus = ExecStatus.Succeeded;

            }
            catch (Exception ex)
            {
                setFailureStatus(ex);
            }
            return ExecuteData;
        }

        private static void Swap(ref char a, ref char b)
        {
            if (a == b) return;

            var temp = a;
            a = b;
            b = temp;
        }

        public static void GetPer(char[] list, ref string permResult)
        {
            int x = list.Length - 1;
            GetPer(list, 0, x, ref permResult);
        }

        private static void GetPer(char[] list, int k, int m , ref string permResult)
        {
            if (k == m)
            {
                permResult += new string(list) + ", ";
            }
            else
                for (int i = k; i <= m; i++)
                {
                    Swap(ref list[k], ref list[i]);
                    GetPer(list, k + 1, m, ref permResult);
                    Swap(ref list[k], ref list[i]);
                }
        }
    }

}
