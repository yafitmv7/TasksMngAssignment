﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tasks.Model
{
    public class PriorityTasksQueue : IPriorityTasksQueue
    {
        private List<Task> _priorityQueue;

        private const string name_missing = "Name doesn't exist";

        public PriorityTasksQueue()
        {
            _priorityQueue = new List<Task>();
        }

        public void AddTask(Task task)
        {
            lock (_priorityQueue)
            {
                _priorityQueue.Add(task);
            }
        }

        public void PrioritizeTask(string taskName, int priority)
        {
            lock (_priorityQueue)
            {
                var taskIdx = _priorityQueue.FindIndex(t => t.Name == taskName);
                if (taskIdx < 0)
                {
                    throw new Exception(name_missing);
                }

                var task = _priorityQueue[taskIdx];
                _priorityQueue.RemoveAt(taskIdx);
                _priorityQueue.Insert(priority, task);
            }
        }

        public void RemoveTask(string taskName)
        {
            lock (_priorityQueue)
            {
                _priorityQueue = _priorityQueue.Where(t =>
                {
                    var ret = t.Name != taskName.Trim();
                    return ret;
                }).ToList();
                //var taskIdx = _priorityQueue.FindIndex(t => t.Name == taskName);
                //if (taskIdx < 0)
                //{
                //    throw new Exception(name_missing);
                //}
                //_priorityQueue.RemoveAt(taskIdx);
            }
        }

        //public Task Dequeue()
        //{
        //    Task task;
        //    lock (_priorityQueue)
        //    {
        //        task = _priorityQueue[0];
        //        _priorityQueue.RemoveAt(0);
        //    }
        //    return task;
        //}

        public List<Task> GetAwaitingTasks()
        {
            lock (_priorityQueue)
            {
                return _priorityQueue.Where(t => t.ExecuteData.ExecutionStatus == ExecStatus.Awaiting).ToList();
            }
        }

        public List<Task> GetAllTasks()
        {
            return _priorityQueue.ToList();
        }

        public override string ToString()
        {
            string ret = "";
            foreach (var task in _priorityQueue)
            {
                ret += task.ToString() + ", ";
            }
            if (ret.Length > 0)
            {
                ret.Remove(ret.Length - 1);
            }
            return ret;
        }

        public int GetNumTasks()
        {
            return _priorityQueue.Count;
        }

        public void UpdateTask(string curName, Task task)
        {
            lock (_priorityQueue)
            {
                var idx = _priorityQueue.FindIndex(t => t.Name == curName);
                if (idx >= 0)
                {
                    _priorityQueue[idx] = task;
                }
            }
        }
    }

    public interface IPriorityTasksQueue
    {
        void AddTask(Task task);
        void PrioritizeTask(string taskName, int priority);
        void RemoveTask(string taskName);
        //Task Dequeue();
        List<Task> GetAwaitingTasks();
        List<Task> GetAllTasks();
        int GetNumTasks();
        void UpdateTask(string curName, Task task);
    }
}
