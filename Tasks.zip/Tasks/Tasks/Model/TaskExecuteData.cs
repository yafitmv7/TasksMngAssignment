﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tasks.Model
{
    public class TaskExecuteData
    {
        public ExecStatus ExecutionStatus { get; set; }
        public string Output { get; set; }
        public string FailureReason { get; set; }

        public TaskExecuteData()
        {
            ExecutionStatus = ExecStatus.Awaiting;
            FailureReason = "N/A";
            Output = string.Empty;
        }
    }

    public enum ExecStatus
    {
        Awaiting = -2,
        Executing = -1,
        Succeeded = 0,
        Failed = 1
    }
}
