﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Tasks.Model;
using AsyncTask = System.Threading.Tasks;

namespace Tasks.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MainController : ControllerBase
    {
        private IPriorityTasksQueue _priorityTasksQueue;

        private IPriorityTasksQueue PriorityTasksQueue
        {
            get
            {
                if (_priorityTasksQueue == null)
                {
                    _priorityTasksQueue = new PriorityTasksQueue();
                }
                return _priorityTasksQueue;
            }
        }

        private static ConcurrentQueue<Task> _runQueue = new ConcurrentQueue<Task>();
        private static ConcurrentQueue<Task> RunQueue
        {
            get
            {
                return _runQueue;
            }
            set
            {
                _runQueue = value;
            }
        }

        public MainController(IPriorityTasksQueue priorityTasksQueue)
        {
            _priorityTasksQueue = priorityTasksQueue;
        }

        [HttpGet("GetAllTasks")]
        public IEnumerable<Model.Task> GetAllTasks()
        {
            return PriorityTasksQueue.GetAllTasks();
        }

        [HttpGet("GetTaskQueue")]
        public IEnumerable<Model.Task> GetTaskQueue()
        {
            return PriorityTasksQueue.GetAwaitingTasks();
        }

        private Task createTask(string name, string input, TaskType type)
        {
            Task task;
            if (type == TaskType.Calculate)
            {
                task = new CalculateTask(name, input);
            }
            else
            {
                task = new PermuteTask(name, input);
            }
            return task;
        }

        [HttpPost("AddTask")]
        public IEnumerable<Task> AddTask(string name, string input, TaskType type)
        {
            var task = createTask(name, input, type);
            PriorityTasksQueue.AddTask(task);
            return PriorityTasksQueue.GetAllTasks();
        }

        [HttpPost("UpdateTask")]
        public IEnumerable<Task> UpdateTask(string curName, string newName, string input, TaskType type)
        {
            var task = createTask(newName, input, type);
            PriorityTasksQueue.UpdateTask(curName, task);
            return PriorityTasksQueue.GetAllTasks();
        }

        [HttpPost("PrioritizeTask")]
        public IEnumerable<Task> PrioritizeTask([FromQuery] string taskName, [FromQuery] int priority)
        {
            PriorityTasksQueue.PrioritizeTask(taskName, priority);
            return PriorityTasksQueue.GetAllTasks();

        }

        [HttpPost("RemoveTask")]
        public IEnumerable<Task> RemoveTask([FromQuery] string taskName)
        {
            PriorityTasksQueue.RemoveTask(taskName);
            return PriorityTasksQueue.GetAwaitingTasks();
        }

        [HttpGet("GetTasksExecuteStatus")]
        public List<Task> GetTasksExecuteStatus()
        {
            return PriorityTasksQueue.GetAllTasks();
        }


        [HttpPost("RunTasks")]
        public  void RunTasks()
        {
            AsyncTask.Task.Run(() => RunTheTasks());
        }   

        private void RunTheTasks()
        {
            RunQueue = new ConcurrentQueue<Task>(PriorityTasksQueue.GetAwaitingTasks());
            while (RunQueue.Count > 0)
            {
                if (RunQueue.TryDequeue(out var task))
                {
                    lock (task)
                    {
                        task.ExecuteData.ExecutionStatus = ExecStatus.Executing;
                        task.ExecuteData = task.Execute();
                        PriorityTasksQueue.UpdateTask(task.Name, task);
                    }
                }
            }
        }

        [HttpGet("IsTaskNameExists")]
        public bool IsTaskNameExists(string taskName)
        {
            return PriorityTasksQueue.GetAllTasks().FirstOrDefault(t => t.Name == taskName) != null;
        }


    }
}
