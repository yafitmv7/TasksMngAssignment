import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SideNavComponent } from './side-nav/side-nav.component';
import { MatInputModule, MatListModule, MatSidenavModule, MatToolbarModule } from '@angular/material';
import { TaskDefinitionComponent } from './task-definition/task-definition.component';
import { MatIconModule } from '@angular/material/icon';
import { TaskExecutionComponent } from './task-execution/task-execution.component';
import { MatTableModule } from '@angular/material/table';
import { AddTaskComponent } from './add-task/add-task.component';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatProgressBarModule} from '@angular/material/progress-bar';

@NgModule({
  declarations: [
    AppComponent,
    SideNavComponent,
    TaskDefinitionComponent,
    TaskExecutionComponent,
    AddTaskComponent,
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: TaskDefinitionComponent, pathMatch: 'full' },
      { path: 'task-def', component: TaskDefinitionComponent },
      { path: 'task-exec', component: TaskExecutionComponent },
    ]),
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    //MatTableModule
    MatCardModule,
    MatDialogModule, 
    MatFormFieldModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatInputModule ,
    MatProgressBarModule
  ],
  entryComponents: [AddTaskComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
