import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Task, TaskType } from '../model/task';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  name = new FormControl( this.data && this.data.name || '' , [Validators.required, Validators.minLength(4), Validators.maxLength(36)]);
  type = new FormControl(this.data && this.data.type || '', [Validators.required]);
  input = new FormControl(this.data && this.data.input || '', [Validators.required, c => this.taskInputValidator(c)]);
  // calcInput = new FormControl('', [Validators.required, Validators.pattern()]);
  // permInput = new FormControl('', [Validators.required, Validators.pattern('[a-zA-z]+'), Validators.minLength(2), Validators.maxLength(7)]);
  taskForm = new FormGroup({
    name: this.name,
    type: this.type,
    // calcInput: this.calcInput,
    // permInput: this.permInput
    input: this.input
  });
  showNameAlreadyExists = false;
  TaskType = TaskType;

  constructor(
    private httpService: HttpService,
    public dialogRef: MatDialogRef<AddTaskComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
  }

  taskInputValidator(control: AbstractControl): { [key: string]: boolean } | null {
  if (this.type.value != undefined) {
    if (this.type.value == TaskType.Calculate) {
      const patt = new RegExp("[0-9\\+\\-\\*\\/\\(\\)]+");
      if (!patt.test(control.value)) {
        return { 'calcExp': true };
      }
      try {
        let regexp = /(?<dig>[0-9])(?<par>\()/g;
        let val = control.value.replace(regexp, '$<dig>*$<par>')
        let res = eval(val);
        if (isNaN(res)) {
          return { 'calcExp': true };
        }
      } catch {
        return { 'calcExp': true };
      }
    } else {
      const patt = new RegExp("[a-zA-Z0-9]+");
      if (!patt.test(control.value)) {
        return { 'permExpPtr': true };
      }
      if (control.value.length < 2 || control.value.length > 7) {
        return { 'permExpLimit': true };
      }
    }
    return null;
  };
}


getNameErrorMessage() {
  if (this.name.hasError('required')) {
    return 'You must enter a name';
  }
  return 'Name must have between 4-36 characters'
}
getInputErrorMessage() {
  if (this.input.hasError('required')) {
    return 'You must enter an input';
  }
  if (this.input.hasError('calcExp')) {
    return 'Please enter a valid calculation expression';
  }
  if (this.input.hasError('permExpPtr')) {
    return 'Please enter an alphanumeric expression';
  }
  if (this.input.hasError('permExpLimit')) {
    return 'Permutation input must have between 2-7 characters';
  }
  return '';
}

onCancel(): void {
  this.dialogRef.close(null);
}

onSave() {
  this.httpService.checkNameExists(this.name.value).subscribe(exists => {
    if (exists) {
      this.showNameAlreadyExists = true;
    } else {
      this.dialogRef.close({
        name: this.name.value,
        type: this.type.value,
        input: this.input.value
      });
    }
  })

}

  }
