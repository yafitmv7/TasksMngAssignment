import { staticViewQueryIds } from '@angular/compiler';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Observable, of, Subscription } from 'rxjs';
import { filter, startWith, switchMap, tap } from 'rxjs/operators';
import { Task, TaskType } from '../model/task';
import { ExecStatus, TaskExecuteData } from '../model/TaskExecuteData';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-task-execution',
  templateUrl: './task-execution.component.html',
  styleUrls: ['./task-execution.component.css']
})
export class TaskExecutionComponent implements OnInit, OnDestroy {
  taskExecutions: Observable<Task[]>;
  ExecStatus = ExecStatus;
  TaskType = TaskType;
  selectedTask = null;
  timeInterval$: Subscription = null;
  readonly SUCCESS = 200;

  constructor(private httpService: HttpService) { }

  ngOnInit() {
    this.httpService.getTaskQueue()
      .subscribe(tasks => this.taskExecutions = tasks);
  }

  getStatusName(status: ExecStatus) {
    return ExecStatus[status];
  }

  runTasks() {
    this.httpService.runTasks().subscribe();

    this.timeInterval$ = interval(1000)
      .pipe(
        startWith(0),
        switchMap(() => this.httpService.getTasksExecuteStatus()),
        filter(res => !!res && res.status == this.SUCCESS)
      ).subscribe(res => {
        this.taskExecutions = res.body;
      })


  }

  ngOnDestroy() {
    if (this.timeInterval$){
      this.timeInterval$.unsubscribe();

    }
  }

}
