import { Component, OnInit } from '@angular/core';
import { Task, TaskType } from '../model/task';
import { HttpService } from '../services/http.service';
import { MatDialog } from '@angular/material/dialog';
import { AddTaskComponent } from '../add-task/add-task.component';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-task-definition',
  templateUrl: './task-definition.component.html',
  styleUrls: ['./task-definition.component.css']
})
export class TaskDefinitionComponent implements OnInit {
  tasks$: Observable<Task[]>;
  TaskType = TaskType;


  constructor(private httpService: HttpService, public dialog: MatDialog) { }

  ngOnInit() {
    this.tasks$ = this.httpService.getTasks();
  }

  openAddTask(task: Task = null): void {
    let curName = task ? task.name : null;

    const dialogRef = this.dialog.open(AddTaskComponent, {
      width: '250px',
      data: task ? { ...task } : null,
      disableClose: true
    });

    if (task) { //edit
      dialogRef.afterClosed().subscribe(_task => {
        if (_task) {
          this.tasks$ = this.httpService.updateTask(curName, _task);//.subscribe(tasks => this.tasks = tasks);
        }
      });
    } else {  //add
      dialogRef.afterClosed().subscribe(_task => {
        if (_task) {
          this.tasks$ = this.httpService.addTask(_task);//.subscribe(tasks => this.tasks = tasks);
        }
      });
    }
  }

  delete(taskName: string) {
    this.tasks$ = this.httpService.deleteTask(taskName);//.subscribe(tasks => this.tasks = tasks);
  }


}
