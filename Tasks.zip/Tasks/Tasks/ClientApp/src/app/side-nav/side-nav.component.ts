import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {
  pages: string[];
  title?: string;

  @Input()
  opened: boolean;

  constructor() {
    this.pages = ['Task Definition', 'Task Execution'];
    this.title = this.pages[0];
   }

  ngOnInit() {
  }

}
