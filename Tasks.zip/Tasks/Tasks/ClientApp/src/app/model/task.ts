import { TaskExecuteData } from "./TaskExecuteData";

export class Task {
    name: string;
    type: TaskType;
    input: string;
    executeData?: TaskExecuteData;
}

export enum TaskType {
    Calculate = 0,
    Premutate = 1
}