export class TaskExecuteData
{
     executionStatus: ExecStatus;
     output: string;
     failureReason: string;
}

export enum ExecStatus
{
    Awaiting = -2,
    Executing = -1,
    Succeeded = 0,
    Failed = 1
}