import { Task } from "./task";

export class ExecuteData {
    allTasks: Task[];
    nRemainingTasks: number;
}