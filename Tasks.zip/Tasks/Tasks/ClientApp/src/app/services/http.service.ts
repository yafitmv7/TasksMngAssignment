import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../model/task';
import { catchError, filter, map, tap } from 'rxjs/operators';
import { ExecuteData } from '../model/executeData';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  private serverUrl: string;

  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.serverUrl = baseUrl + 'main/';
  }

  getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.serverUrl + 'GetAllTasks').pipe(
      catchError(error => { console.error(error); return []; })
    );
  }

  checkNameExists(taskName: string): Observable<boolean> {
    return this.http.get<Task[]>(this.serverUrl + 'IsTaskNameExists?taskName=' + taskName).pipe(
      catchError(error => { console.error(error); return []; })
    );
  }

  addTask(task: Task): Observable<Task[]> {
    const input = task.input.replace(/\+/gi, '%2B');
    return this.http.post<Task[]>(this.serverUrl + `AddTask?name=${task.name}&input=${input}&type=${task.type}`,
      null, {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8')
    }).pipe(
      catchError(error => { console.error(error); return []; })
    );
  }

  deleteTask(taskName: string) {
    return this.http.post<Task[]>(this.serverUrl + `RemoveTask?taskName=${taskName}`, null).pipe(
      catchError(error => { console.error(error); return []; })
    );
  }
  updateTask(oldName: string, task: any) {
    const input = task.input.replace(/\+/gi, '%2B');
    return this.http.post<Task[]>(this.serverUrl + `UpdateTask?curName=${oldName}&newName=${task.name}&input=${input}&type=${task.type}`, null).pipe(
      catchError(error => { console.error(error); return []; })
    );
  }
  getTaskQueue() {
    return this.http.get<Task[]>(this.serverUrl + 'GetTaskQueue').pipe(
      catchError(error => { console.error(error); return []; })
    );
  }

  getTasksExecuteStatus() {
    return this.http.get<ExecuteData>(this.serverUrl + 'getTasksExecuteStatus', { observe: 'response'})
    .pipe(
      filter(tasks => !!tasks),
      catchError(error => { console.error(error); return []; })
    );
  }

  runTasks() {
    return this.http.post<void>(this.serverUrl + 'RunTasks', null).pipe(
      catchError(error => { console.error(error); return []; })
    );
  }



}